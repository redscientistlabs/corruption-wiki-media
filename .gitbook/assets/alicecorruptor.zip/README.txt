Hi! Thanks for downloading the AliceCorruptor.

To use it, simply open the AliceCorruptor.exe, 
Type the name of the program you want to corrupt under "Executable" (Make sure you know its file name and DON'T type ".exe" after it. The corruptor already handles that on its own.)

Select a common byte (or a custom byte if you know which ones work the best) and start corrupting! (I can recommend 3F800000, it gives the best results most of the time.)


To prevent crashing, make sure to keep a low intensity.




The following common bytes:
ULTIMATE S (Gets, not as many bytes as ULTIMATE)
ULTIMATE (Gets a lot of bytes)
CRASH (Gets every single possible address, might crash your PC so use at your own risk.)

These common bytes are unstable and will crash a lot more often than the others, however. If corrupted correctly, you should get some amazing results.






This corruptor was designed specifically for PC applications and games, for true realtime corrupting. Previously you had to corrupt the files first, just to get disappointed later on.
Or you'd be forced to use Cheat Engine to scan for certain addresses and change them (which, often didn't work or it'd just crash the game regardless)


This corruptor was made using Cheat Engine and Cheat Engine Lua.







For questions, or more information and updates - Head over to our discord at discord.gg/eKRXtw8


// AliceTS