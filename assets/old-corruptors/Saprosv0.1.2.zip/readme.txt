Sapros v0.1.2
-----------
Written By Dan

Release: 31/01/2005

Introduction
------------

Sapros is a very simple file corruptor written in Delphi 7. It was written
in a few hours on Boxing Day of 2004.

What's New
----------

0.1.2 - Fixed the bug with the Restore ROM feature not working as advertised. :P

0.1.1 - Added a fix due to the fact that CDLs now only contain the PRG ROM,
        which wasn't the case in the beta versions.

History
-------

I first started Sapros many years ago, (roughly 2) to be an easy to use
file corruptor. However, I got very bored, and never actually finished it.

I picked up the idea of a file corruptor again, when I got a beta version
of FCEUXD, which had the code/data logger built-in. This thing could log
all data that was accessed in a ROM, making using a corruptor a lot more
precise. (which is the main problem with corruptors)

So, I got the file format off bbitmaster, and wrote a tool in C# to display
all the data offsets in a CDL file. After that, I got bored again, and never
did anything else with it.

Shoot forward to Christmas Day, and the FCEUXD public release. This release
got me interested again, and I decided to finish up my display program.
I decided to dump C#, and move to Delphi to widen my audience. I kept most
of the interface from the old Sapros, and built a new corruptor. The work
took less than 2 hours, for the extremely basic feature set that was in v0.1.

Features
--------

- Loading of CDL files for data ranges
- Corrupt bytes in a certain range by either replacing the bytes with a certain
  byte, increasing or decreasing the bytes, or randomizing them.
- Backups your ROM, so you can revert it to the fine working state.
- Exports CDL data ranges to a text file.

Future Plans
------------

- Maybe a built-in hex editor to view the corruption areas.
- Hex Workshop launching of corruption area.
- More corruption options.
- ???

Thanks
------

- bbitmaster

Contact
-------

Homepage: http://dan.panicus.org
Email: dan@panicus.dontbotherspammingme.org <-- remove the dontbotherspammingme bit
